### Name: pdata-class
### Title: Class "pdata"
### Aliases: ptypes pdata-class [<-,pdata-method [,pdata-method
###   [[,pdata-method [[<-,pdata-method [[,pdata,ANY,ANY-method
###   [[,pdata,ANY,missing-method $,pdata-method $<-,pdata-method
### Keywords: classes

### ** Examples





