### Name: multiPhylo-class
### Title: multiPhylo4 and extended classes
### Aliases: multiPhylo-class multiPhylo4-class multiPhylo4d-class
### Keywords: classes

### ** Examples

  library(ape)
  example(read.tree)
  p1 = tree.owls
  P1 = as(tree.owls,"phylo4")
  P1
  sumryP1 = summary(P1)
  sumryP1



