### Name: phylo4
### Title: create a phylogenetic tree object
### Aliases: phylo4
### Keywords: classes

### ** Examples

# a three species tree:
mytree <- phylo4(edge=matrix(data=c(4,1, 4,5, 5,2, 5,3), ncol=2, byrow=TRUE), tip.label=c("speciesA", "speciesB", "speciesC"))
mytree
plot(mytree)

# another way to specify the same tree:
mytree <- phylo4(edge=cbind(c(4,4,5,5), c(1,5,2,3)), tip.label=c("speciesA", "speciesB", "speciesC"))

# another way:
mytree <- phylo4(edge=rbind(c(4,1), c(4,5), c(5,2), c(5,3)), tip.label=c("speciesA", "speciesB", "speciesC"))

# with branch lengths:
mytree <- phylo4(edge=rbind(c(4,1), c(4,5), c(5,2), c(5,3)), tip.label=c("speciesA", "speciesB", "speciesC"), edge.length=c(1, .2, .8, .8))
plot(mytree)



