### Name: plot for phylo4 and phylo4d
### Title: Plot a phylogenetic tree alone or with data
### Aliases: plot,phylo4,missing-method plot,phylo4d,missing-method
### Keywords: misc hplot

### ** Examples

if(require(ape)){
## build data
example("phylo4d")
obj1 <- obj2 <- obj3 <- phylo4d(as(tree.owls,"phylo4"),data.frame(wing=1:4,color=factor(c("b","w","b","b")), tail=runif(4)*10), use.tip.names=FALSE)

obj2@tip.data <- as.data.frame(obj2@tip.data[,1])
obj3@tip.data <- cbind(obj1@tip.data,obj2@tip.data)
obj4 <- obj1
obj4$tip.data[2,3] <- NA
obj4$tip.data[1,1] <- NA

## several plots
plot(obj1)
plot(obj2,box=FALSE,symbol="sq",var.lab="My legend for the variable",ratio=.6,center=FALSE,scale=FALSE,leg=TRUE,cex.leg=1.5)
plot(obj3,leg=TRUE,cex.leg=1.2,treetype="clado",adj=-.5,srt=90)
plot(obj4,edge.color=rainbow(6),edge.width=1:6)

if(require(ade4)){
data(mjrochet)
temp <- as(read.tree(text=mjrochet$tre),"phylo4")
obj <- phylo4d(x=temp,tip.data=mjrochet$tab)
obj
plot(obj,cex.lab=.5,show.node=FALSE,cex.sym=.6)
}
}



