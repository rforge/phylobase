### Name: phylo4d-methods
### Title: Combine a phylogenetic tree with data
### Aliases: phylo4d phylo4d-methods phylo4d,phylo4-method
###   phylo4d,matrix-method phylo4d,phylo-method
### Keywords: misc

### ** Examples

library(ape)
example(read.tree)
try(phylo4d(as(tree.owls.bis,"phylo4"),data.frame(wing=1:3)), silent=TRUE)
phylo4d(as(tree.owls.bis,"phylo4"),data.frame(wing=1:3), use.tip.names=FALSE)



