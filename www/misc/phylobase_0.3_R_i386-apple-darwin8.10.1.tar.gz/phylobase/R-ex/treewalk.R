### Name: treewalk
### Title: tree traversal and utility functions
### Aliases: getAncest getDescend allDescend allAncest MRCA getNodeByLabel
###   getLabelByNode
### Keywords: misc

### ** Examples

  library(geiger)
  data(geospiza)
  g1 <- as(geospiza$geospiza.tree,"phylo4")
getLabelByNode(g1,18)
getNodeByLabel(g1,"N04")
## rename nodes for clarity
  n1 <- phylobase::nTips(g1)+1
  n2 <- phylobase::nTips(g1)+nNodes(g1)
  NodeLabels(g1) <- paste("N",n1:n2,sep="")
  plot(g1,show.node.label=TRUE)
  getAncest(g1,"N20")
  getDescend(g1,"N20")
  allDescend(g1,"N20")
  allAncest(g1,"N20")
  MRCA(g1,"conirostris","difficilis","fuliginosa")
  MRCA(g1,"olivacea","conirostris")



