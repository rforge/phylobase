### Name: coerce-methods
### Title: Converting between phylo4 and other phylogenetic trees
### Aliases: coerce-methods coerce,phylo,phylo4-method
###   coerce,phylo,phylo4d-method coerce,multiPhylo4,multiPhylo-method
###   coerce,multiPhylo,multiPhylo4-method
###   coerce,multiPhylo4d,multiPhylo-method coerce,phylo4,phylo-method
###   coerce,phylo4d,phylo-method coerce,phylo4,data.frame-method
###   coerce,phylo4d,data.frame-method
### Keywords: methods

### ** Examples

    library(ape)
  example(read.tree)
## round trip conversion 
  tree_in_phylo = tree.owls               # tree is a phylo object 
  tree_in_phylo4 = as(tree.owls,"phylo4")  # phylo converted to phylo4 
  tree_in_phylo4
  identical(tree_in_phylo,as(tree_in_phylo4,"phylo")) # test if phylo, and phlyo4 converted to phylo are identical

  as(tree_in_phylo4, "phylog")     # conversion to phylog (ade4)
  as(tree_in_phylo4, "data.frame")  # conversion to data.frame
  as(tree_in_phylo4, "phylo")      # conversion to phylo (ape)
  as(tree_in_phylo4, "phylo4d")    # conversion to phylo4d, but without data so data slots empty.



