### Name: subset-methods
### Title: Methods for creating subsets of phylogenies
### Aliases: subset subset-methods subset,phylo-method subset,phylo4-method
###   subset,phylo4d-method
### Keywords: manip methods

### ** Examples

library(geiger)
data(geospiza)
g1 <- as(geospiza$geospiza.tree,"phylo4")
plot(subset(g1,tips.exclude="scandens"))
plot(subset(g1,mrca=c("scandens","fortis","pauper")))
plot(subset(g1,node.subtree=18))



