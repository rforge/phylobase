### Name: hasSingles
### Title: Test trees for polytomies or inline nodes
### Aliases: hasSingles hasPoly
### Keywords: misc

### ** Examples

library(ape)
example(read.tree)
owls4 = as(tree.owls.bis,"phylo4")
hasPoly(owls4)
hasSingles(owls4)



