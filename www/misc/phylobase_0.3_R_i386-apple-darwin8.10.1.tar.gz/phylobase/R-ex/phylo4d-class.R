### Name: phylo4d-class
### Title: phylo4d class
### Aliases: phylo4d-class show,phylo4d-method print,phylo4d-method
###   summary,phylo4d-method names,phylo4d-method
### Keywords: classes

### ** Examples

  library(ape)
  example(read.tree)
  obj <- phylo4d(as(tree.owls.bis,"phylo4"),data.frame(wing=1:3), use.tip.names=FALSE)
  obj
  names(obj)
  summary(obj)



