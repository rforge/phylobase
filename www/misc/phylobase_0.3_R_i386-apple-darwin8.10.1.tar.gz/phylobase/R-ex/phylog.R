### Name: phylog-class
### Title: Class "phylog"
### Aliases: phylog-class coerce,phylo4,phylog-method
### Keywords: classes

### ** Examples




