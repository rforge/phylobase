### Name: prune-methods
### Title: Methods for dropping tips
### Aliases: prune prune-methods prune,phylo-method prune,phylo4-method
###   prune,phylo4d-method na.omit,phylo4d-method DropTip
### Keywords: manip methods

### ** Examples

require(ape)
data(bird.families)
tip <- c(
"Eopsaltriidae", "Acanthisittidae", "Pittidae", "Eurylaimidae",
"Philepittidae", "Tyrannidae", "Thamnophilidae", "Furnariidae",
"Formicariidae", "Conopophagidae", "Rhinocryptidae", "Climacteridae",
"Menuridae", "Ptilonorhynchidae", "Maluridae", "Meliphagidae",
"Pardalotidae", "Petroicidae", "Irenidae", "Orthonychidae",
"Pomatostomidae", "Laniidae", "Vireonidae", "Corvidae",
"Callaeatidae", "Picathartidae", "Bombycillidae", "Cinclidae",
"Muscicapidae", "Sturnidae", "Sittidae", "Certhiidae",
"Paridae", "Aegithalidae", "Hirundinidae", "Regulidae",
"Pycnonotidae", "Hypocoliidae", "Cisticolidae", "Zosteropidae",
"Sylviidae", "Alaudidae", "Nectariniidae", "Melanocharitidae",
"Paramythiidae","Passeridae", "Fringillidae")
plot(as(prune(bird.families, tip),"phylo"))
plot(as(prune(bird.families, tip, trim.internal = FALSE),"phylo"))
data(bird.orders)
plot(as(prune(bird.orders, 6:23, subtree = TRUE),"phylo"), font = 1)
plot(as(prune(bird.orders, c(1:5, 20:23), subtree = TRUE), "phylo"), font = 1)

### Examples of the use of `root.edge'
tr <- as(ape::read.tree(text = "(A:1,(B:1,(C:1,(D:1,E:1):1):1):1):1;"),"phylo4")
prune(tr, c("A", "B"), root.edge = 0) # = (C:1,(D:1,E:1):1);
prune(tr, c("A", "B"), root.edge = 1) # = (C:1,(D:1,E:1):1):1;
prune(tr, c("A", "B"), root.edge = 2) # = (C:1,(D:1,E:1):1):2;
prune(tr, c("A", "B"), root.edge = 3) # = (C:1,(D:1,E:1):1):3;

## Dropping tips on phylo4d objects
r1 <- rcoal(5)
d <- data.frame(a=1:5,row.names=paste("t",1:5,sep=""))
phylo4d(r1,tip.data=d,node.data=data.frame(a=6:9))
prune(r1,1)



