### Name: phylo4-class
### Title: phylo4 and extended classes
### Aliases: phylo-class phylo4-class $,phylo4-method $<-,phylo4-method
###   print,phylo4-method show,phylo4-method summary,phylo4-method
###   names,phylo4-method
### Keywords: classes

### ** Examples

  library(ape)
  example(read.tree)
  p1 = tree.owls
  P1 = as(tree.owls,"phylo4")
  P1
  sumryP1 = summary(P1)
  sumryP1



